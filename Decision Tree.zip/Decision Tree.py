#!/usr/bin/env python
# coding: utf-8

# In[2]:


import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.tree import DecisionTreeClassifier
from sklearn import tree
from sklearn.metrics import classification_report
from sklearn import preprocessing


# In[4]:


df1 = pd.read_csv('C:\\Users\\Admin\\Downloads\\Fraud_check.csv')
df1.head()


# In[7]:


for i in range(len(df1['Taxable.Income'])):
    if df1['Taxable.Income'][i] <= 30000:
        df1['Taxable.Income'][i] = 'risky'
    else:
        df1['Taxable.Income'][i] = 'good'


# In[9]:



df1.head()


# In[11]:


colnames = list(df1.columns)
colnames


# In[12]:


df1 = pd.get_dummies(df1)
df1


# In[14]:


df2= df1.drop('Marital.Status_Single', axis=1)
df3= df2.drop('Marital.Status_Divorced', axis=1)
df4= df3.drop('Undergrad_NO', axis=1)
df5= df4.drop('Urban_NO',axis=1)


# In[16]:


df = df5.drop('Taxable.Income_good', axis=1)
df


# In[18]:


df1=df.rename({'Undergrad_YES':'Undergrad','Marital.Status_Married':'Marital.Status','Urban_YES':'Urban','Taxable.Income_risky':'Taxable.Income'}, axis=1)
df1


# In[20]:


x=df1.iloc[:, [0,1,2,3,5]]
y=df1.iloc[:,4]


# In[22]:


x,y


# In[24]:


x


# In[26]:


y


# In[28]:


# Splitting data into training and testing data set
x_train, x_test, y_train, y_test = train_test_split(x,y, test_size=0.2, random_state=50)


# In[29]:


###Building Decision Tree Classifier


# In[30]:


model = DecisionTreeClassifier(criterion = 'entropy', max_depth=3)
model.fit(x_train, y_train)


# In[31]:


#PLot the decision tree
tree.plot_tree(model)


# In[33]:


from IPython.display import Image  
from sklearn.externals.six import StringIO  
from sklearn.tree import export_graphviz
import pydot 

features = list(df1.columns[1:])
features


# In[35]:


dot_data = StringIO()  
export_graphviz(model, out_file=dot_data,feature_names=features,filled=True,rounded=True)
graph = pydot.graph_from_dot_data(dot_data.getvalue())  
Image(graph[0].create_png())


# In[37]:


#Predicting on test data
preds = model.predict(x_test) # predicting on test data set 
pd.Series(preds).value_counts() # getting the count of each category


# In[39]:


preds


# In[40]:


pd.crosstab(y_test,preds) # getting the 2 way table to understand the correct and wrong predictions


# In[41]:


# Accuracy 
np.mean(preds==y_test)


# In[42]:


####Building Decision Tree Classifier (CART) using Gini Criteria


# In[43]:


from sklearn.tree import DecisionTreeClassifier
model_gini = DecisionTreeClassifier(criterion='gini', max_depth=3)


# In[44]:


model_gini.fit(x_train, y_train)


# In[45]:


#Prediction and computing the accuracy
pred = model.predict(x_test)
np.mean(pred==y_test)


# In[46]:


tree.plot_tree(model_gini);


# In[47]:


fn=['Undergrad','Marital.Status','City.Population','Work.Experience','Urban']
cn=['Taxable.Income']
fig, axes = plt.subplots(nrows = 1,ncols = 1,figsize = (4,4), dpi=700)
tree.plot_tree(model_gini,feature_names = fn, class_names= cn, filled = True);


# In[49]:


dot_data = StringIO()  
export_graphviz(model_gini, out_file=dot_data,feature_names=features,filled=True,rounded=True)
graph = pydot.graph_from_dot_data(dot_data.getvalue())  
Image(graph[0].create_png())


# In[50]:


###Post pruning decision trees with cost complexity pruning


# In[51]:


path = model_gini.cost_complexity_pruning_path(x_train, y_train)
ccp_alphas, impurities = path.ccp_alphas, path.impurities


# In[52]:


ccp_alphas


# In[53]:


clfs = []
for ccp_alpha in ccp_alphas:
    clf = DecisionTreeClassifier(random_state=0, ccp_alpha=ccp_alpha)
    clf.fit(x_train, y_train)
    clfs.append(clf)
print("Number of nodes in the last tree is: {} with ccp_alpha: {}".format(
      clfs[-1].tree_.node_count, ccp_alphas[-1]))


# In[55]:


train_scores = [clf.score(x_train, y_train) for clf in clfs]
test_scores = [clf.score(x_test, y_test) for clf in clfs]

fig, ax = plt.subplots()
ax.set_xlabel("alpha")
ax.set_ylabel("accuracy")
ax.set_title("Accuracy vs alpha for training and testing sets")
ax.plot(ccp_alphas, train_scores, marker='o', label="train",
        drawstyle="steps-post")
ax.plot(ccp_alphas, test_scores, marker='o', label="test",
        drawstyle="steps-post")
ax.legend()
plt.show()


# In[56]:


clf = DecisionTreeClassifier(random_state=0, ccp_alpha=0.00345)
clf.fit(x_train,y_train)


# In[57]:


pred = clf.predict(x_test)
from sklearn.metrics import accuracy_score
accuracy_score(y_test, pred)


# In[59]:


from sklearn import tree
plt.figure(figsize=(15,10))
tree.plot_tree(clf,filled=True)


# In[61]:


# Decision Tree Regression
from sklearn.tree import DecisionTreeRegressor


# In[62]:


X_train, X_test, y_train, y_test = train_test_split(x,y, test_size=0.30, random_state=1)


# In[63]:


model = DecisionTreeRegressor(random_state=50, ccp_alpha=0.00345)
model.fit(X_train, y_train)


# In[64]:


#Find the accuracy
model.score(X_test, y_test)


# In[65]:


tree.plot_tree(model);


# In[66]:


fn=['Undergrad','Marital.Status','City.Population','Work.Experience','Urban']
cn=['Taxable.Income']
fig, axes = plt.subplots(nrows = 1,ncols = 1,figsize = (4,4), dpi=700)
tree.plot_tree(model,feature_names = fn, class_names= cn, filled = True);


# In[ ]:




